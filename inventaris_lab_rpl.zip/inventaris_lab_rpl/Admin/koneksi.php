<?php

$conn = mysqli_connect('localhost','root','','inventory') or die($conn);

?>
